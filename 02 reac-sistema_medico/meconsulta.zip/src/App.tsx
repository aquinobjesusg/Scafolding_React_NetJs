import { Hero } from "@/components/Hero"
import { ProductsByService } from "@/components/ProductsByService"
import { Features } from "@/components/Features"
import { Testimonials } from "@/components/Testimonials"
import { CTA } from "@/components/CTA"
import { Footer } from "@/components/Footer"
import { Header } from "@/components/Header"
import { MedicalSpecialtiesSheet } from "@/components/MedicalSpecialtiesSheet"
import { ProductsSheet } from "@/components/ProductsSheet"
import { MarketplacesCatalogSheet } from "@/components/MarketplacesCatalogSheet"
import { AboutCompanySheet } from "@/components/AboutCompanySheet"

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans antialiased">
      <Header />
      <main>
        <Hero />
        <ProductsByService />
        <Features />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
      <MedicalSpecialtiesSheet />
      <ProductsSheet />
      <MarketplacesCatalogSheet />
      <AboutCompanySheet />
    </div>
  )
}
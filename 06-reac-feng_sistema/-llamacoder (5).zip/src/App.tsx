import { useState } from "react";
import { Landing } from "@/components/Landing";
import { AuthModal } from "@/components/AuthModal";
import { AdminPanel } from "@/components/AdminPanel";

export default function App() {
  const [view, setView] = useState<"landing" | "admin">("landing");
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register" | "forgot">("login");

  const openAuth = (mode: "login" | "register" | "forgot") => {
    setAuthMode(mode);
    setAuthOpen(true);
  };

  const handleAuthSuccess = () => {
    setAuthOpen(false);
    setView("admin");
  };

  if (view === "admin") {
    return <AdminPanel onExit={() => setView("landing")} />;
  }

  return (
    <>
      <Landing onAuth={openAuth} onEnterAdmin={() => setView("admin")} />
      <AuthModal
        open={authOpen}
        mode={authMode}
        onModeChange={setAuthMode}
        onClose={() => setAuthOpen(false)}
        onSuccess={handleAuthSuccess}
      />
    </>
  );
}
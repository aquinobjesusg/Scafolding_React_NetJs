import React, { useState } from 'react';
import { 
  Globe, 
  Mail, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Award, 
  Heart, 
  Send, 
  Check, 
  CreditCard,
  BookOpen
} from 'lucide-react';

interface FooterProps {
  onNavigateView?: (view: any) => void;
  onScrollToSection?: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateView, onScrollToSection }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<'es' | 'en' | 'pt'>('es');
  const [currentCurrency, setCurrentCurrency] = useState<'USD' | 'EUR' | 'MXN'>('USD');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setSubscribed(false);
    }, 3500);
  };

  return (
    <footer className="border-t border-orange-100 bg-gradient-to-b from-white via-orange-50/20 to-orange-50/60 text-gray-700">
      {/* Top Banner: Newsletter & Trust Pillars */}
      <div className="border-b border-orange-100/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 sm:py-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-center">
          <div className="space-y-1">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-orange-600 uppercase tracking-widest bg-orange-100/70 px-2.5 py-0.5 rounded-full">
              Comunidad Global
            </span>
            <h3 className="text-lg font-black text-gray-900">
              Aprende a tu ritmo con lecciones interactivas
            </h3>
            <p className="text-xs text-gray-500">
              Suscríbete para recibir lanzamientos de cursos, becas y promociones exclusivas.
            </p>
          </div>

          {/* Newsletter Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 max-w-lg lg:ml-auto">
              <input
                type="email"
                required
                placeholder="Ingresa tu correo electrónico..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-xs text-gray-900 placeholder-gray-400 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-hidden transition-all shadow-2xs"
              />
              <button
                type="submit"
                className="flex items-center justify-center gap-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 px-5 py-2.5 text-xs font-bold text-white shadow-sm transition-all active:scale-[0.98]"
              >
                {subscribed ? (
                  <>
                    <Check className="h-4 w-4" />
                    <span>¡Suscrito!</span>
                  </>
                ) : (
                  <>
                    <Send className="h-3.5 w-3.5" />
                    <span>Suscribirme</span>
                  </>
                )}
              </button>
            </form>
            {subscribed && (
              <p className="text-[11px] text-emerald-600 font-semibold mt-1.5 lg:text-right">
                Te enviamos un cupón de bienvenida con 20% de descuento a tu bandeja.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Main Multi-Column Footer Information */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 sm:py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 sm:gap-10 text-xs">
        {/* Column 1: Brand & Bio */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500 text-white shadow-md shadow-orange-500/20">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <span className="text-base font-black tracking-tight text-gray-950">
                MedEdu <span className="text-orange-500">Pro</span>
              </span>
              <p className="text-[11px] font-medium text-orange-600">
                Campus de Especialidades Médicas & CME
              </p>
            </div>
          </div>

          <p className="text-gray-600 leading-relaxed max-w-sm text-xs">
            Plataforma médica líder para formación de especialistas y educación médica continua (CME). Incluye transmisión de procedimientos quirúrgicos en 4K, simulación de casos clínicos, bitácoras, panel hospitalario con exportación nativa a Excel y acreditación oficial.
          </p>

          {/* Contact Details */}
          <div className="space-y-2 pt-2 text-gray-600">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-orange-500 shrink-0" />
              <span>contacto@mededupro.health • academica@mededupro.health</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-orange-500 shrink-0" />
              <span>+1 (800) 456-7890 • Guardias Médicas 24/7</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-orange-500 shrink-0" />
              <span>Av. Médica Universitaria 1200, Pabellón Quirúrgico, Torre Docente</span>
            </div>
          </div>

          {/* Social Links */}
          <div className="pt-2">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-2">
              Redes & Canales Científicos
            </span>
            <div className="flex items-center gap-2">
              {[
                { name: 'Twitter / X', symbol: '𝕏', href: 'https://twitter.com' },
                { name: 'LinkedIn', symbol: 'in', href: 'https://linkedin.com' },
                { name: 'YouTube Clínico', symbol: '▶', href: 'https://youtube.com' },
                { name: 'ResearchGate', symbol: 'RG', href: 'https://researchgate.net' },
                { name: 'Instagram Médico', symbol: 'ig', href: 'https://instagram.com' },
                { name: 'Facebook', symbol: 'fb', href: 'https://facebook.com' },
              ].map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  title={s.name}
                  className="flex h-8 w-8 items-center justify-center rounded-lg border border-orange-200 bg-white font-bold text-gray-700 hover:bg-orange-500 hover:text-white hover:border-orange-500 transition-all shadow-2xs"
                >
                  <span className="text-[11px]">{s.symbol}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Column 2: 22 Especialidades Médicas */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900 border-b border-orange-100 pb-2">
            22 Especialidades Médicas
          </h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Cardiología Clínica e Intervencionista</a></li>
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Neurología & Neurofisiología</a></li>
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Cirugía General & Laparoscópica</a></li>
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Pediatría & Neonatología</a></li>
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Anestesiología & Reanimación</a></li>
            <li><a href="#catalogo" onClick={() => onScrollToSection?.('catalogo')} className="hover:text-orange-600 transition-colors">Ver las 22 Especialidades →</a></li>
          </ul>
        </div>

        {/* Column 3: Plataforma & Funcionalidades */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900 border-b border-orange-100 pb-2">
            Campus & Herramientas
          </h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#features" onClick={() => onScrollToSection?.('features')} className="hover:text-orange-600 transition-colors">Reproductor Quirúrgico en HD/4K</a></li>
            <li><a href="#features" onClick={() => onScrollToSection?.('features')} className="hover:text-orange-600 transition-colors">Casos Clínicos & Rúbricas CME</a></li>
            <li><a href="#features" onClick={() => onScrollToSection?.('features')} className="hover:text-orange-600 transition-colors">Diplomas Acreditados con ID Folio</a></li>
            <li><a href="#features" onClick={() => onScrollToSection?.('features')} className="hover:text-orange-600 transition-colors">Exportación a Excel de Bases de Datos</a></li>
            <li><a href="#features" onClick={() => onScrollToSection?.('features')} className="hover:text-orange-600 transition-colors">Pasarela de Aranceles & Becas Médicas</a></li>
            <li>
              <button 
                onClick={() => onNavigateView?.('admin-dashboard')} 
                className="text-orange-600 font-bold hover:underline"
              >
                Panel Administrativo Hospitalario →
              </button>
            </li>
          </ul>
        </div>

        {/* Column 4: Institucional, Equipo y Legal */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-900 border-b border-orange-100 pb-2">
            Comité & Hospitales
          </h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#equipo" onClick={() => onScrollToSection?.('equipo')} className="hover:text-orange-600 transition-colors">Cuerpo Docente de Especialistas</a></li>
            <li><a href="#contacto" onClick={() => onScrollToSection?.('contacto')} className="hover:text-orange-600 transition-colors">Formulario de Contacto & Soporte</a></li>
            <li><a href="#privacidad" onClick={(e) => { e.preventDefault(); alert('Política de Privacidad Médica: Cumplimiento estricto con normativas de confidencialidad y protección de datos clínicos.'); }} className="hover:text-orange-600 transition-colors">Privacidad y Confidencialidad</a></li>
            <li><a href="#terminos" onClick={(e) => { e.preventDefault(); alert('Reglamento de Matrícula: Válido para créditos CME y certificaciones de residencia según colegios médicos.'); }} className="hover:text-orange-600 transition-colors">Reglamento Académico</a></li>
            <li><a href="#garantia" onClick={(e) => { e.preventDefault(); alert('Garantía de Excelencia Docente: 30 días de acceso con garantía de satisfacción.'); }} className="hover:text-orange-600 transition-colors">Garantía de Satisfacción</a></li>
            <li><a href="#faq" onClick={() => alert('Consulta a nuestro MedBot flotante en la esquina inferior derecha para asistencia guiada paso a paso.')} className="hover:text-orange-600 transition-colors">Guía del Campus (MedBot)</a></li>
          </ul>
        </div>
      </div>

      {/* Language, Currency & Copyright Bar */}
      <div className="border-t border-orange-100 bg-white/70 py-6 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <div className="flex items-center gap-4">
            {/* Language Picker */}
            <div className="flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-2.5 py-1 text-gray-700">
              <Globe className="h-3.5 w-3.5 text-orange-500" />
              <select
                value={currentLanguage}
                onChange={(e) => setCurrentLanguage(e.target.value as any)}
                className="bg-transparent text-xs font-semibold outline-hidden cursor-pointer"
              >
                <option value="es">Español (ES / Latam)</option>
                <option value="en">English (US)</option>
                <option value="pt">Português (BR)</option>
              </select>
            </div>

            {/* Currency Picker */}
            <div className="flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-2.5 py-1 text-gray-700">
              <CreditCard className="h-3.5 w-3.5 text-orange-500" />
              <select
                value={currentCurrency}
                onChange={(e) => setCurrentCurrency(e.target.value as any)}
                className="bg-transparent text-xs font-semibold outline-hidden cursor-pointer"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="MXN">MXN ($)</option>
              </select>
            </div>
          </div>

          {/* Copyright notice */}
          <div className="flex items-center gap-1 text-[11px] text-gray-500 text-center sm:text-right">
            <span>© {new Date().getFullYear()} MedEdu Pro - Campus de Especialidades Médicas & CME. Todos los derechos reservados.</span>
            <span className="hidden md:inline">• Excelencia en Formación Médica Continua</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

import React from 'react';
import { 
  PlaySquare, 
  HelpCircle, 
  LayoutDashboard, 
  FileSpreadsheet, 
  CreditCard, 
  BarChart3, 
  Award, 
  Sparkles, 
  ShieldCheck, 
  Zap,
  CheckCircle2,
  Users,
  Stethoscope,
  Activity
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: Stethoscope,
      title: '22 Especialidades Médicas',
      badge: 'Currículo Oficial 2026',
      description: 'Programas formativos completos en Cardiología, Neurología, Cirugía General, Pediatría, Anestesiología y más, adaptados a directrices de posgrado.',
      color: 'bg-orange-50 text-orange-600 border-orange-200',
    },
    {
      icon: PlaySquare,
      title: 'Reproductor Quirúrgico Integrado',
      badge: 'Video 1080p & 4K',
      description: 'Transmisión fluida de procedimientos quirúrgicos en vivo, disecciones anatómicas, ajuste de velocidad (0.75x a 2x) y pantalla completa.',
      color: 'bg-amber-50 text-amber-600 border-amber-200',
    },
    {
      icon: HelpCircle,
      title: 'Discusión de Casos & Rúbricas',
      badge: 'Evaluación CME',
      description: 'Simuladores de casos clínicos reales con diagnósticos diferenciales, opciones terapéuticas justificadas y retroalimentación inmediata.',
      color: 'bg-orange-50 text-orange-600 border-orange-200',
    },
    {
      icon: Award,
      title: 'Créditos CME y Diploma Oficial',
      badge: 'Acreditación Válida',
      description: 'Certificados emitidos automáticamente al completar los módulos clínicos, avalados con horas crédito CME y folio único verificable.',
      color: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    },
    {
      icon: LayoutDashboard,
      title: 'Panel Administrativo Hospitalario',
      badge: 'Jefatura & Docencia',
      description: 'Gestión integral de médicos residentes, docentes especialistas, aranceles y matriz de permisos por jerarquía hospitalaria.',
      color: 'bg-blue-50 text-blue-600 border-blue-200',
    },
    {
      icon: FileSpreadsheet,
      title: 'Exportación a Excel en 1 Clic',
      badge: 'Nativo .xls / CSV',
      description: 'Descarga al instante el padrón de médicos, matrícula de residentes, catálogo de 22 especialidades e informes contables en formato Excel.',
      color: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    },
    {
      icon: CreditCard,
      title: 'Aranceles, Becas & Cupones',
      badge: 'Checkout Seguro',
      description: 'Pasarela de pagos encriptada para tarjetas de crédito, PayPal y Mercado Pago con soporte para becas hospitalarias (MEDCME50, BECA100).',
      color: 'bg-orange-50 text-orange-600 border-orange-200',
    },
    {
      icon: Activity,
      title: 'Bitácora & Notas de Visita',
      badge: 'Persistencia Local',
      description: 'Área interactiva para registrar notas de evolución, dosis farmacológicas y perlas clínicas que se conservan de forma segura en tu navegador.',
      color: 'bg-rose-50 text-rose-600 border-rose-200',
    },
  ];

  return (
    <section id="features" className="py-14 sm:py-20 bg-gradient-to-b from-orange-50/40 via-white to-orange-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-orange-100 px-3 py-1 text-xs font-bold text-orange-700">
            <Sparkles className="h-3.5 w-3.5 text-orange-500" />
            <span>Características del Campus Médico Digital</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-gray-950">
            Plataforma Médica Integral de 22 Especialidades y Educación Continua
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
            Formación médica de vanguardia con experiencia interactiva estilo Udemy, respaldo de docentes especialistas de hospitales universitarios y sistema administrativo con exportación a Excel.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="group relative rounded-2xl border border-orange-100/90 bg-white p-6 shadow-2xs hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl border ${item.color} shadow-2xs group-hover:scale-110 transition-transform`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="rounded-full bg-orange-50 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-orange-700 border border-orange-200/60">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-gray-900 group-hover:text-orange-600 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs text-gray-500 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-gray-100 flex items-center gap-1.5 text-[11px] font-bold text-orange-600">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Incluido en el Campus</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

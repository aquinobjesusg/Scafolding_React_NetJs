import React from 'react';
import { 
  Star, 
  Users, 
  BookOpen, 
  Linkedin, 
  Award,
  Sparkles,
  Building2,
  Stethoscope
} from 'lucide-react';

export const TeamSection: React.FC = () => {
  const team = [
    {
      name: 'Dra. Valentina Montes',
      role: 'Directora Médica & Jefa de Cardiología',
      specialty: 'Cardiología Intervencionista & Hemodinamia',
      hospital: 'Hospital Clínico Universitario',
      avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&auto=format&fit=crop&q=80',
      bio: 'Fellow del Colegio Americano de Cardiología (FACC). Más de 15 años liderando programas de cateterismo y acreditación de residencias.',
      cmeCredits: '120 hrs CME',
      studentsCount: '4,850 médicos',
      rating: 4.9,
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Dr. Alejandro Morales',
      role: 'Coordinador de Neurología Clínica',
      specialty: 'Neurofisiología & Accidente Cerebrovascular',
      hospital: 'Instituto Nacional de Neurología',
      avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80',
      bio: 'Pionero en protocolos de trombólisis endovenosa y autor de más de 40 publicaciones indexadas en Neurociencias y Medicina Crítica.',
      cmeCredits: '95 hrs CME',
      studentsCount: '3,920 médicos',
      rating: 4.9,
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Dra. Camila Restrepo',
      role: 'Jefa del Área Quirúrgica',
      specialty: 'Cirugía General & Laparoscopía Avanzada',
      hospital: 'Hospital Metropolitano de Especialidades',
      avatar: 'https://images.unsplash.com/photo-1594824813639-4467389a9f24?w=300&auto=format&fit=crop&q=80',
      bio: 'Miembro del Colegio Internacional de Cirujanos. Docente en simulación quirúrgica mínimamente invasiva y manejo perioperatorio.',
      cmeCredits: '110 hrs CME',
      studentsCount: '5,140 médicos',
      rating: 4.8,
      linkedin: 'https://linkedin.com',
    },
    {
      name: 'Dr. Roberto Fontanarrosa',
      role: 'Jefe de Medicina Interna & UCI',
      specialty: 'Medicina Intensiva & Fisiopatología Crítica',
      hospital: 'Centro Médico Universitario',
      avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300&auto=format&fit=crop&q=80',
      bio: 'Especialista en soporte hemodinámico, ventilación mecánica y análisis de casos clínicos de alta complejidad en cuidados intensivos.',
      cmeCredits: '85 hrs CME',
      studentsCount: '4,210 médicos',
      rating: 4.9,
      linkedin: 'https://linkedin.com',
    },
  ];

  return (
    <section id="equipo" className="py-14 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-orange-100 pb-8">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-orange-100 px-3 py-1 text-xs font-bold text-orange-700">
              <Sparkles className="h-3.5 w-3.5 text-orange-500" />
              <span>Cuerpo Docente & Comité de Especialidades</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-gray-950">
              Equipo de Colaboración Médica y Jefaturas Docentes
            </h2>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
              Profesores titulares, jefes de servicio y especialistas activos en los principales hospitales universitarios imparten cada una de las 22 especialidades.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-orange-700 bg-orange-50 px-3.5 py-1.5 rounded-xl border border-orange-200">
              ★ 4.9/5 Evaluación Promedio Docente
            </span>
          </div>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <div
              key={index}
              className="group rounded-2xl border border-orange-100/90 bg-white p-5 shadow-2xs hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Photo & Badge */}
                <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-orange-50">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2 rounded-lg bg-black/60 backdrop-blur-xs px-2 py-0.5 text-[10px] font-bold text-white flex items-center gap-1">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                    <span>{member.rating}</span>
                  </div>
                  <div className="absolute bottom-2 left-2 rounded-md bg-orange-600/90 backdrop-blur-xs px-2 py-0.5 text-[10px] font-bold text-white">
                    {member.cmeCredits}
                  </div>
                </div>

                {/* Member Info */}
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-gray-900 group-hover:text-orange-600 transition-colors">
                    {member.name}
                  </h3>
                  <p className="text-[11px] font-bold text-orange-600">
                    {member.role}
                  </p>
                  <p className="text-[11px] font-medium text-gray-600">
                    {member.specialty}
                  </p>
                  <div className="flex items-center gap-1 text-[10px] text-gray-400 pt-0.5">
                    <Building2 className="h-3 w-3 text-orange-400 shrink-0" />
                    <span className="truncate">{member.hospital}</span>
                  </div>
                </div>

                <p className="text-xs text-gray-600 leading-relaxed line-clamp-3">
                  {member.bio}
                </p>
              </div>

              {/* Stats & Social */}
              <div className="pt-4 mt-4 border-t border-gray-100 space-y-3">
                <div className="flex items-center justify-between text-[11px] text-gray-500">
                  <span className="flex items-center gap-1">
                    <Stethoscope className="h-3 w-3 text-orange-500" />
                    <strong>Especialista</strong> Activo
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3 text-orange-500" />
                    <strong>{member.studentsCount}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-100 text-gray-600 hover:bg-orange-500 hover:text-white transition-colors"
                    title="Perfil Profesional"
                  >
                    <Linkedin className="h-3.5 w-3.5" />
                  </a>
                  <span className="text-[11px] font-medium text-gray-400">
                    Certificado por el Consejo Médico
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { useCourse } from '../../context/CourseContext';
import { useAuth } from '../../context/AuthContext';
import { Course } from '../../types';
import { 
  Search, 
  Star, 
  Users, 
  Clock, 
  PlayCircle, 
  CheckCircle2, 
  Sparkles, 
  Filter, 
  GraduationCap, 
  BookOpen, 
  Zap 
} from 'lucide-react';

interface UdemyCatalogProps {
  onSelectCourse: (course: Course) => void;
  onOpenPlayer: (courseId: string) => void;
  onOpenPayment: (course: Course) => void;
  onOpenAuth: () => void;
}

export const UdemyCatalog: React.FC<UdemyCatalogProps> = ({
  onSelectCourse,
  onOpenPlayer,
  onOpenPayment,
  onOpenAuth,
}) => {
  const { courses, isUserEnrolled, getCourseProgressPercent } = useCourse();
  const { currentUser } = useAuth();

  const [selectedCategory, setSelectedCategory] = useState<string>('TODOS');
  const [selectedLevel, setSelectedLevel] = useState<string>('TODOS');
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyMyCourses, setOnlyMyCourses] = useState(false);

  const categories = [
    'TODOS',
    'Especialidades Clínicas',
    'Especialidades Quirúrgicas',
    'Salud Materno-Infantil',
    'Urgencias & Cuidados Críticos',
    'Diagnóstico & Imagen',
  ];

  const levels = [
    'TODOS',
    'Residencia Médica',
    'Especialista',
    'Alta Especialidad',
    'Todos los niveles',
  ];

  const filteredCourses = courses.filter((course) => {
    // Only published for catalog
    if (course.status !== 'Publicado') return false;

    // "Mis Cursos" filter
    if (onlyMyCourses && !isUserEnrolled(course.id)) return false;

    // Category filter
    if (selectedCategory !== 'TODOS' && course.category !== selectedCategory) return false;

    // Level filter
    if (selectedLevel !== 'TODOS' && course.level !== selectedLevel) return false;

    // Search term
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchTitle = course.title.toLowerCase().includes(term);
      const matchInstructor = course.instructorName.toLowerCase().includes(term);
      const matchDesc = course.shortDescription.toLowerCase().includes(term);
      if (!matchTitle && !matchInstructor && !matchDesc) return false;
    }

    return true;
  });

  return (
    <div id="catalogo" className="space-y-8 pb-12">
      {/* Hero Banner with Warm Orange & Dark Charcoal Gradient */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-gray-950 via-gray-900 to-orange-950 p-8 sm:p-12 text-white shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full bg-orange-500/20 px-3.5 py-1 text-xs font-bold text-orange-300 border border-orange-500/30">
            <Sparkles className="h-4 w-4 text-amber-300" />
            <span>Campus de Posgrado • 22 Especialidades Médicas Oficiales</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
            Programa de Educación Médica Continua & Especialidades Clínico-Quirúrgicas
          </h1>

          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            Formación avanzada para médicos residentes, especialistas y cirujanos: video cirugías en HD, análisis fisiopatológico, simulación de casos clínicos interactivos y créditos CME acreditados por sociedades científicas.
          </p>

          {/* Search bar inside hero */}
          <div className="relative max-w-lg pt-2">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="¿Qué especialidad o patología buscas? Ej. Cardiología, Ictus, Cirugía..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-2xl border border-white/20 bg-white/10 backdrop-blur-md pl-12 pr-4 py-3.5 text-xs text-white placeholder-gray-400 focus:bg-white focus:text-gray-900 focus:placeholder-gray-500 outline-hidden transition-all shadow-lg"
            />
          </div>
        </div>

        {/* Decorative background glow in warm orange */}
        <div className="absolute right-0 top-0 -mr-20 -mt-20 h-96 w-96 rounded-full bg-orange-500/15 blur-3xl" />
        <div className="absolute right-40 bottom-0 h-64 w-64 rounded-full bg-amber-600/15 blur-2xl" />
      </div>

      {/* Category Pills & Filters */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'bg-white border border-gray-200 text-gray-700 hover:bg-orange-50 hover:border-orange-200'
                }`}
              >
                {cat === 'TODOS' ? 'Todas las 22 Especialidades' : cat}
              </button>
            ))}
          </div>

          {/* Switch for enrolled courses */}
          {currentUser && (
            <button
              onClick={() => setOnlyMyCourses(!onlyMyCourses)}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all ${
                onlyMyCourses
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white border border-gray-200 text-gray-700 hover:bg-orange-50'
              }`}
            >
              <BookOpen className="h-4 w-4" />
              <span>Mis Especialidades Matriculadas</span>
            </button>
          )}
        </div>

        {/* Secondary Level Filter */}
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Filter className="h-3.5 w-3.5 text-gray-400" />
          <span className="font-semibold">Nivel Clínico:</span>
          {levels.map((lvl) => (
            <button
              key={lvl}
              onClick={() => setSelectedLevel(lvl)}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                selectedLevel === lvl
                  ? 'bg-orange-100 text-orange-800 font-bold'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              {lvl === 'TODOS' ? 'Todos los Niveles' : lvl}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      {filteredCourses.length === 0 ? (
        <div className="rounded-3xl border border-gray-200 bg-white p-12 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-gray-300 mb-3" />
          <h3 className="text-base font-bold text-gray-900">No se encontraron especialidades</h3>
          <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
            Prueba ajustando los filtros por categoría clínica o buscando otro término.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('TODOS');
              setSelectedLevel('TODOS');
              setSearchTerm('');
              setOnlyMyCourses(false);
            }}
            className="mt-4 rounded-xl bg-orange-50 px-4 py-2 text-xs font-bold text-orange-700 hover:bg-orange-100"
          >
            Restablecer Filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCourses.map((course) => {
            const enrolled = isUserEnrolled(course.id);
            const progress = enrolled ? getCourseProgressPercent(course.id) : 0;

            let totalMinutes = 0;
            course.sections.forEach((s) => s.lessons.forEach((l) => (totalMinutes += l.durationMinutes)));
            const hours = Math.floor(totalMinutes / 60);

            return (
              <div
                key={course.id}
                onClick={() => onSelectCourse(course)}
                className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-gray-200/90 bg-white shadow-2xs hover:shadow-lg transition-all cursor-pointer hover:-translate-y-1"
              >
                <div>
                  {/* Thumbnail and badges */}
                  <div className="relative aspect-video w-full overflow-hidden bg-gray-100">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />

                    {/* CME Credits Badge */}
                    {course.cmeCredits && (
                      <span className="absolute top-2 left-2 rounded-md bg-orange-600 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-white shadow-xs">
                        {course.cmeCredits} Horas CME
                      </span>
                    )}

                    {/* Enrolled badge */}
                    {enrolled && (
                      <span className="absolute top-2 right-2 flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-0.5 text-[10px] font-bold text-white shadow-xs">
                        <CheckCircle2 className="h-3 w-3" />
                        Matriculado
                      </span>
                    )}
                  </div>

                  {/* Body Content */}
                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between text-[10px] text-gray-500 font-semibold">
                      <span className="text-orange-600 font-bold bg-orange-50 px-2 py-0.5 rounded">
                        {course.category}
                      </span>
                      <span>{course.level}</span>
                    </div>

                    <h3 className="font-bold text-xs sm:text-sm text-gray-900 line-clamp-2 leading-snug group-hover:text-orange-600 transition-colors">
                      {course.title}
                    </h3>

                    <p className="text-[11px] text-gray-500 line-clamp-2">
                      {course.shortDescription}
                    </p>

                    <div className="text-[11px] text-gray-700 font-medium truncate">
                      <span className="font-bold text-gray-900">{course.instructorName}</span>
                      {course.hospitalAffiliation && (
                        <span className="text-gray-400 block text-[10px] truncate">{course.hospitalAffiliation}</span>
                      )}
                    </div>

                    {/* Ratings */}
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-extrabold text-amber-700">{course.rating.toFixed(1)}</span>
                      <div className="flex text-amber-400">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-3 w-3 fill-amber-400" />
                        ))}
                      </div>
                      <span className="text-[10px] text-gray-400">
                        ({course.studentsCount.toLocaleString()} médicos)
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-gray-500 pt-0.5">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {hours > 0 ? `${hours}h ` : '45h '}clínicas
                      </span>
                      <span>•</span>
                      <span>{course.sections.reduce((acc, s) => acc + s.lessons.length, 0)} lecciones</span>
                    </div>
                  </div>
                </div>

                {/* Card Footer: Price and CTA */}
                <div className="border-t border-gray-100 bg-orange-50/20 p-4">
                  {enrolled ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-gray-600 font-medium">
                        <span>Progreso de especialidad:</span>
                        <span className="font-bold text-orange-600">{progress}%</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-gray-200 overflow-hidden">
                        <div
                          className="h-full bg-orange-500 rounded-full transition-all duration-500"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenPlayer(course.id);
                        }}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-orange-500 py-2 text-xs font-bold text-white shadow-2xs hover:bg-orange-600 transition-colors"
                      >
                        <PlayCircle className="h-3.5 w-3.5" />
                        <span>Continuar Especialidad</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-base font-black text-gray-900">
                            ${course.price.toFixed(2)}
                          </span>
                          <span className="text-xs text-gray-400 line-through">
                            ${course.originalPrice.toFixed(2)}
                          </span>
                        </div>
                        <span className="text-[10px] text-gray-400 block">Matrícula anual</span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenPayment(course);
                        }}
                        className="flex items-center gap-1 rounded-xl bg-gray-900 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-orange-500 transition-colors shadow-2xs"
                      >
                        <span>Matricular</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

import { Course, Permission, Role, SystemConfig, Transaction, User } from './types';

export const INITIAL_PERMISSIONS: Permission[] = [
  { id: 'p1', name: 'Ver Especialidades Médicas', code: 'courses.read', category: 'Cursos', description: 'Visualizar el catálogo y lecciones de las 22 especialidades médicas' },
  { id: 'p2', name: 'Crear Especialidades y Módulos', code: 'courses.create', category: 'Cursos', description: 'Crear nuevos programas de especialidad médica, cirugías y seminarios' },
  { id: 'p3', name: 'Editar Contenido Clínico', code: 'courses.update', category: 'Cursos', description: 'Actualizar guías de práctica clínica, videos y quizzes de evaluación' },
  { id: 'p4', name: 'Archivar Especialidad', code: 'courses.delete', category: 'Cursos', description: 'Permite archivar o dar de baja programas de especialidad' },
  
  { id: 'p5', name: 'Ver Directorio de Médicos', code: 'users.read', category: 'Usuarios', description: 'Consultar médicos especialistas, residentes e internistas registrados' },
  { id: 'p6', name: 'Gestionar Médicos y Matrículas', code: 'users.manage', category: 'Usuarios', description: 'Dar de alta médicos, verificar cédulas y suspender cuentas' },
  { id: 'p7', name: 'Administrar Roles Hospitalarios', code: 'roles.manage', category: 'Usuarios', description: 'Asignar permisos a Directores Médicos, Docentes y Auditores' },
  
  { id: 'p8', name: 'Ver Analítica Médica', code: 'reports.read', category: 'Reportes', description: 'Revisar estadísticas de aprobación, retención y horas de crédito CME' },
  { id: 'p9', name: 'Exportar Informes a Excel', code: 'reports.export', category: 'Reportes', description: 'Descargar padrones y balances académicos en formato Excel (.xls)' },
  
  { id: 'p10', name: 'Ver Aranceles y Matrículas', code: 'finance.read', category: 'Finanzas', description: 'Historial de pagos de matrículas y becas de especialidad' },
  { id: 'p11', name: 'Gestionar Becas y Reembolsos', code: 'finance.refund', category: 'Finanzas', description: 'Procesar reintegros o becas institucionales de formación' },
  
  { id: 'p12', name: 'Configuración del Campus Médico', code: 'settings.manage', category: 'Configuración', description: 'Parámetros de acreditación médica continua, pasarelas y correos' },
];

export const INITIAL_ROLES: Role[] = [
  {
    id: 'r1',
    name: 'Director Médico (Super Admin)',
    code: 'ADMIN',
    description: 'Dirección académica y ejecutiva del campus médico, comités de acreditación y supervisión global.',
    userCount: 2,
    permissions: INITIAL_PERMISSIONS.map(p => p.code),
    isSystem: true,
  },
  {
    id: 'r2',
    name: 'Docente Especialista Titular',
    code: 'INSTRUCTOR',
    description: 'Médico especialista responsable de la cátedra, grabación de procedimientos clínicos y diseño de quizzes.',
    userCount: 8,
    permissions: ['courses.read', 'courses.create', 'courses.update', 'reports.read', 'reports.export'],
    isSystem: true,
  },
  {
    id: 'r3',
    name: 'Médico Residente / Cursante',
    code: 'STUDENT',
    description: 'Acceso a las 22 especialidades médicas, streaming de cirugías, casos clínicos y certificados CME.',
    userCount: 42,
    permissions: ['courses.read'],
    isSystem: true,
  },
  {
    id: 'r4',
    name: 'Auditor de Calidad Médica',
    code: 'EDITOR',
    description: 'Revisa concordancia con guías de práctica clínica internacionales (AHA, ESC, CDC, WHO) y material didáctico.',
    userCount: 3,
    permissions: ['courses.read', 'courses.update', 'reports.read'],
    isSystem: false,
  },
];

export const INITIAL_USERS: User[] = [
  {
    id: 'u1',
    name: 'Dr. Alejandro Morales',
    email: 'admin@edupro.com',
    role: 'ADMIN',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-01-10',
    lastLogin: '2026-09-08 20:30',
    enrolledCourses: ['med-c1', 'med-c2', 'med-c6', 'med-c20'],
    medicalLicense: 'CMP-74892 / RNE-44120',
    specialty: 'Medicina Crítica y Dirección Hospitalaria',
    hospital: 'Hospital General Universitario',
  },
  {
    id: 'u2',
    name: 'Dr. Carlos Santana',
    email: 'carlos@edupro.com',
    role: 'INSTRUCTOR',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-02-14',
    lastLogin: '2026-09-08 17:15',
    coursesCreated: 6,
    enrolledCourses: ['med-c1'],
    medicalLicense: 'CMP-51203 / RNE-31089',
    specialty: 'Cardiología Intervencionista',
    hospital: 'Instituto Nacional Cardiovascular',
  },
  {
    id: 'u3',
    name: 'Dra. Elena Valenzuela',
    email: 'elena@edupro.com',
    role: 'INSTRUCTOR',
    avatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-03-01',
    lastLogin: '2026-09-07 11:20',
    coursesCreated: 5,
    enrolledCourses: ['med-c2'],
    medicalLicense: 'CMP-63401 / RNE-28711',
    specialty: 'Neurología Vascular y Neurociencias',
    hospital: 'Hospital de Alta Especialidad Neurológica',
  },
  {
    id: 'u4',
    name: 'Dra. María Fernández',
    email: 'maria@edupro.com',
    role: 'STUDENT',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-05-19',
    lastLogin: '2026-09-08 19:40',
    enrolledCourses: ['med-c1', 'med-c3', 'med-c7', 'med-c20'],
    medicalLicense: 'CMP-89104 (Residente R3)',
    specialty: 'Residencia en Medicina de Emergencias',
    hospital: 'Hospital Metropolitano de Urgencias',
  },
  {
    id: 'u5',
    name: 'Dr. Javier Domínguez',
    email: 'javier@edupro.com',
    role: 'STUDENT',
    avatar: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-06-22',
    lastLogin: '2026-09-06 21:04',
    enrolledCourses: ['med-c6', 'med-c8'],
    medicalLicense: 'CMP-92340 (Residente R2)',
    specialty: 'Residencia en Cirugía General',
    hospital: 'Hospital Quirúrgico Central',
  },
  {
    id: 'u6',
    name: 'Dra. Lucía Méndez',
    email: 'lucia@edupro.com',
    role: 'EDITOR',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    status: 'Activo',
    createdAt: '2025-07-08',
    lastLogin: '2026-09-04 11:45',
    enrolledCourses: [],
    medicalLicense: 'CMP-49201',
    specialty: 'Epidemiología y Bioestadística Médica',
    hospital: 'Comité de Ética e Investigación Clínica',
  },
  {
    id: 'u7',
    name: 'Dr. Rodrigo Benítez',
    email: 'rodrigo@inactivo.com',
    role: 'STUDENT',
    avatar: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&auto=format&fit=crop&q=80',
    status: 'Inactivo',
    createdAt: '2025-08-11',
    lastLogin: '2026-08-10 16:30',
    enrolledCourses: [],
    medicalLicense: 'CMP-94510',
    specialty: 'Médico Cirujano General',
    hospital: 'Clínica San Gabriel',
  }
];

// 22 Distinct Medical Specialties with comprehensive clinical curricula
export const INITIAL_COURSES: Course[] = [
  // 1. CARDIOLOGÍA
  {
    id: 'med-c1',
    title: 'Cardiología Clínica e Intervencionista',
    slug: 'cardiologia-clinica-intervencionista',
    shortDescription: 'Síndromes coronarios agudos, electrocardiografía avanzada, insuficiencia cardíaca, arritmias complejas y hemodinámica.',
    description: 'Formación de posgrado médico basada en las directrices conjuntas de la American Heart Association (AHA) y European Society of Cardiology (ESC). Incluye interpretación sistemática de 12 derivaciones de ECG, ecocardiografía transtorácica, manejo del shock cardiogénico y técnicas de cateterismo.',
    category: 'Especialidades Clínicas',
    level: 'Alta Especialidad',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.96,
    ratingCount: 2840,
    studentsCount: 14200,
    thumbnail: 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    status: 'Publicado',
    updatedAt: '2026-09-02',
    cmeCredits: 60,
    hospitalAffiliation: 'Instituto Nacional Cardiovascular (INCOR)',
    accreditationCode: 'CME-CARDIO-2026-A1',
    features: [
      '60 Horas Académicas acreditadas CME (AMA PRA Category 1)',
      'Simulador interactivo de ECG con 50 trazados patológicos reales',
      'Video cirugías de angioplastia coronaria e implante de TAVI en HD',
      'Guías farmacológicas ESC/AHA 2026 descargables',
      'Certificado Oficial con validez ante Colegios Médicos'
    ],
    sections: [
      {
        id: 's1-cardio',
        title: 'Módulo 1: Electrocardiografía Clínica Avanzada & Arritmias',
        order: 1,
        lessons: [
          {
            id: 'l1-c1',
            title: '1. Diagnóstico Diferencial de Taquicardias de QRS Ancho (Brugada vs Vereckei)',
            durationMinutes: 24,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            isCompleted: true,
            resources: [
              { name: 'Algoritmo_Taquicardias_QRS_Ancho.pdf', url: '#', size: '3.1 MB' },
              { name: 'Atlas_Trazados_ECG_Patologicos.pdf', url: '#', size: '14.2 MB' }
            ]
          },
          {
            id: 'l2-c1',
            title: '2. Síndromes Coronarios Agudos con y sin Elevación del ST (SCA)',
            durationMinutes: 32,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            isCompleted: true,
            resources: [{ name: 'Guia_ESC_SCA_2026.pdf', url: '#', size: '5.8 MB' }]
          },
          {
            id: 'l3-c1',
            title: '3. Caso Clínico Interactivo con Quiz: Paciente con Dolor Torácico Opresivo',
            durationMinutes: 15,
            type: 'quiz',
            isCompleted: false,
            quizQuestions: [
              {
                id: 'qc1-1',
                question: 'Varón de 62 años hipertenso y fumador acude con dolor retroesternal opresivo de 45 min. El ECG muestra elevación de 3mm en DII, DIII y aVF con descenso especular en DI y aVL. ¿Cuál es el vaso coronario responsable más probable?',
                options: [
                  'Arteria Coronaria Derecha (ACD)',
                  'Arteria Descendente Anterior (DA)',
                  'Arteria Circunfleja (Cx)',
                  'Tronco Coronario Izquierdo (TCI)'
                ],
                correctAnswerIndex: 0,
                explanation: 'La elevación del segmento ST en las derivaciones inferiores (DII, DIII y aVF) con DIII > DII y descenso en aVL indica compromiso de la cara diafragmática tributaria de la Arteria Coronaria Derecha (en un 85-90% de dominancia derecha).'
              },
              {
                id: 'qc1-2',
                question: 'Ante un IAM con elevación del ST de menos de 2 horas de evolución en un centro con laboratorio de hemodinámica disponible, ¿cuál es el tiempo objetivo puerta-balón (angioplastia primaria)?',
                options: [
                  '< 90 minutos',
                  '< 120 minutos',
                  '< 30 minutos',
                  '< 180 minutos'
                ],
                correctAnswerIndex: 0,
                explanation: 'Las guías clínicas internacionales establecen que si el paciente ingresa en un centro con capacidad de angioplastia primaria, el tiempo puerta-balón debe ser menor de 90 minutos (y menor de 60 min si llega en ambulancia con preaviso).'
              }
            ]
          }
        ]
      },
      {
        id: 's2-cardio',
        title: 'Módulo 2: Insuficiencia Cardíaca con FEVI Reducida y Cuádruple Terapia',
        order: 2,
        lessons: [
          {
            id: 'l4-c1',
            title: '4. Farmacoterapia Basada en Evidencia: Los 4 Pilares de la IC (ARNI, iSGLT2, BB, ARM)',
            durationMinutes: 28,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            isCompleted: false
          },
          {
            id: 'l5-c1',
            title: '5. Lectura Clínica: Titulación de Fármacos y Manejo de la Hiperpotasemia',
            durationMinutes: 12,
            type: 'article',
            articleContent: 'El inicio y titulación rápida de los 4 pilares en insuficiencia cardíaca reduce la mortalidad cardiovascular en más de un 60%. El uso combinado de Sacubitrilo/Valsartán, Dapagliflozina o Empagliflozina, Betabloqueantes (Carvedilol, Bisoprolol) y Antagonistas del Receptor Mineralocorticoide (Espironolactona) es el estándar oro actual.'
          }
        ]
      }
    ]
  },

  // 2. NEUROLOGÍA
  {
    id: 'med-c2',
    title: 'Neurología y Neurociencias Clínicas',
    slug: 'neurologia-neurociencias-clinicas',
    shortDescription: 'Ictus isquémico y hemorrágico, epilepsia refractaria, cefaleas complejas, demencias y esclerosis múltiple.',
    description: 'Abordaje de patologías neurológicas prevalentes y de urgencia. Aprende la escala NIHSS, criterios de trombólisis endovenosa con r-tPA, trombectomía mecánica en ventana extendida de 24h, protocolos de electroencefalografía y mapeo de pares craneales.',
    category: 'Especialidades Clínicas',
    level: 'Alta Especialidad',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 159.99,
    rating: 4.94,
    ratingCount: 1980,
    studentsCount: 9800,
    thumbnail: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-28',
    cmeCredits: 55,
    hospitalAffiliation: 'Instituto de Ciencias Neurológicas',
    accreditationCode: 'CME-NEURO-2026-B2',
    features: [
      '55 Créditos CME certificados',
      'Entrenamiento interactivo en Escala NIHSS y TC Perfusion',
      'Casos en video de trombectomía mecánica cerebral en sala angiográfica',
      'Protocolo de manejo de estatus epiléptico convulsivo'
    ],
    sections: [
      {
        id: 's1-neuro',
        title: 'Módulo 1: Código Ictus y Terapia de Reperfusión Cerebral',
        order: 1,
        lessons: [
          {
            id: 'l1-c2',
            title: '1. Evaluación NIHSS y Criterios de Selección para Trombólisis con Alteplasa / Tenecteplasa',
            durationMinutes: 26,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            isCompleted: false
          },
          {
            id: 'l2-c2',
            title: '2. Quiz Clínico: Diagnóstico Rápido de ACV Isquémico Agudo',
            durationMinutes: 12,
            type: 'quiz',
            isCompleted: false,
            quizQuestions: [
              {
                id: 'qneuro-1',
                question: 'Mujer de 68 años es traída por familiares con afasia motora y hemiparesia derecha densa iniciada hace 1 hora y 45 min. La TC simple no muestra hemorragia ni signos tempranos de isquemia extensos (ASPECTS 10). Presión arterial 160/90 mmHg. ¿Cuál es el tratamiento inmediato más apropiado?',
                options: [
                  'Trombólisis intravenosa con Alteplasa o Tenecteplasa tras confirmar ausencia de contraindicaciones',
                  'Administrar Ácido Acetilsalicílico 300 mg de inmediato y esperar evolución 24 horas',
                  'Descender la presión arterial con nitroprusiato a menos de 120/80 mmHg antes de cualquier fármaco',
                  'Realizar punción lumbar de urgencia'
                ],
                correctAnswerIndex: 0,
                explanation: 'El paciente se encuentra dentro de la ventana terapéutica (< 4.5 horas) para trombólisis endovenosa, sin contraindicaciones hemorrágicas y con presión arterial dentro del límite seguro (< 185/110 mmHg).'
              }
            ]
          }
        ]
      }
    ]
  },

  // 3. PEDIATRÍA
  {
    id: 'med-c3',
    title: 'Pediatría y Neonatología Integral',
    slug: 'pediatria-neonatologia-integral',
    shortDescription: 'Reanimación neonatal (PRN), emergencias pediátricas (PALS), infectología infantil, nutrición y crecimiento.',
    description: 'Capacitación intensiva en el cuidado del paciente desde el recién nacido prematuro hasta el adolescente. Domina la escala de dificultad respiratoria de Silverman-Andersen, reanimación cardiopulmonar pediátrica, dosificación ponderal precisa y vacunación.',
    category: 'Salud Materno-Infantil',
    level: 'Residencia Médica',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 149.99,
    rating: 4.97,
    ratingCount: 2150,
    studentsCount: 11300,
    thumbnail: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-20',
    cmeCredits: 50,
    hospitalAffiliation: 'Hospital Nacional Docente Materno Infantil',
    accreditationCode: 'CME-PED-2026-C3',
    features: [
      '50 Horas de Crédito Académico Pediátrico',
      'Simulador de dosis ponderal y calculadoras pediátricas',
      'Videos prácticos de intubación neonatal y canalización umbilical',
      'Protocolos PALS 2026 actualizados'
    ],
    sections: [
      {
        id: 's1-ped',
        title: 'Módulo 1: Emergencias Respiratorias Pediátricas y Sepsis',
        order: 1,
        lessons: [
          {
            id: 'l1-c3',
            title: '1. Bronquiolitis Aguda, Laringotraqueítis (Crup) y Asma Severo',
            durationMinutes: 28,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 4. DERMATOLOGÍA
  {
    id: 'med-c4',
    title: 'Dermatología Clínica y Quirúrgica',
    slug: 'dermatologia-clinica-quirurgica',
    shortDescription: 'Dermatoscopía de lesiones pigmentadas, melanoma, psoriasis, dermatosis inflamatorias y biopsias cutáneas.',
    description: 'Formación profunda en diagnóstico visual dermatoscópico (criterios ABCDE y regla de los 3 puntos), fotoprotección, terapias biológicas en eccema y psoriasis severa, y técnicas quirúrgicas de escisión cutánea y colgajos.',
    category: 'Especialidades Clínicas',
    level: 'Especialista',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 39.99,
    originalPrice: 139.99,
    rating: 4.92,
    ratingCount: 1420,
    studentsCount: 7800,
    thumbnail: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-22',
    cmeCredits: 45,
    hospitalAffiliation: 'Centro Dermatológico Internacional',
    accreditationCode: 'CME-DERMA-2026-D4',
    features: [
      '45 Créditos CME con Atlas de Dermatoscopía HD',
      'Guía de interpretación de biopsias y tinciones inmunohistoquímicas',
      'Protocolos de inmunobiológicos en dermatitis atópica'
    ],
    sections: [
      {
        id: 's1-derma',
        title: 'Módulo 1: Dermatoscopía Avanzada y Detección Temprana de Cáncer Cutáneo',
        order: 1,
        lessons: [
          {
            id: 'l1-c4',
            title: '1. Diagnóstico Diferencial: Nevus Atípico vs Melanoma Maligno',
            durationMinutes: 22,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 5. ONCOLOGÍA MÉDICA
  {
    id: 'med-c5',
    title: 'Oncología Médica y Terapias Dirigidas',
    slug: 'oncologia-medica-terapias-dirigidas',
    shortDescription: 'Inmunoterapia con inhibidores de checkpoint (anti-PD-1), terapias moleculares, estadificación TNM y cuidados paliativos.',
    description: 'Abordaje multidisciplinario de los principales tumores sólidos (mama, pulmón, colon, próstata). Incluye análisis genómico tumoral, toxicidad de la inmunoterapia y manejo de emergencias oncológicas como el síndrome de lisis tumoral y compresión medular.',
    category: 'Especialidades Clínicas',
    level: 'Alta Especialidad',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 54.99,
    originalPrice: 189.99,
    rating: 4.98,
    ratingCount: 1650,
    studentsCount: 6900,
    thumbnail: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    status: 'Publicado',
    updatedAt: '2026-09-01',
    cmeCredits: 60,
    hospitalAffiliation: 'Instituto Nacional de Enfermedades Neoplásicas',
    accreditationCode: 'CME-ONCO-2026-E5',
    features: [
      '60 Horas Acreditadas ESMO/ASCO',
      'Panel molecular interactivo (EGFR, ALK, KRAS, BRAF, HER2, BRCA1/2)',
      'Algoritmos de quimioterapia e inmunoterapia basada en biomarcadores'
    ],
    sections: [
      {
        id: 's1-onco',
        title: 'Módulo 1: Biomarcadores y Terapia Celular Dirigida',
        order: 1,
        lessons: [
          {
            id: 'l1-c5',
            title: '1. Inmunoterapia en Cáncer de Pulmón No Microcítico Avanzado',
            durationMinutes: 30,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 6. CIRUGÍA GENERAL Y LAPAROSCÓPICA
  {
    id: 'med-c6',
    title: 'Cirugía General y Laparoscópica Avanzada',
    slug: 'cirugia-general-laparoscopica',
    shortDescription: 'Colecistectomía dificultosa, plastia inguinal TAPP/TEP, abdomen agudo quirúrgico, trauma penetrante y suturas laparoscópicas.',
    description: 'Programa quirúrgico con grabaciones en alta definición desde quirófano. Aprende visión crítica de seguridad de Strasberg, triangulación de trócares, manejo del sangrado intraoperatorio, anastomosis intestinales mecánicas y protocolo ERAS.',
    category: 'Especialidades Quirúrgicas',
    level: 'Residencia Médica',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 59.99,
    originalPrice: 199.99,
    rating: 4.97,
    ratingCount: 3100,
    studentsCount: 15400,
    thumbnail: 'https://images.unsplash.com/photo-1551076805-e1869033e561?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    status: 'Publicado',
    updatedAt: '2026-09-03',
    cmeCredits: 65,
    hospitalAffiliation: 'Hospital Central de Cirugía y Trasplantes',
    accreditationCode: 'CME-SURG-2026-F6',
    features: [
      '65 Horas de Crédito Quirúrgico CME',
      'Video procedimientos reales en 4K con anatomía quirúrgica paso a paso',
      'Entrenamiento de nudos intracorpóreos y simulación laparoscópica',
      'Manejo de complicaciones intraoperatorias y fístulas'
    ],
    sections: [
      {
        id: 's1-surg',
        title: 'Módulo 1: Visión Crítica de Seguridad y Colecistectomía Compleja',
        order: 1,
        lessons: [
          {
            id: 'l1-c6',
            title: '1. Los 3 Criterios de Strasberg y Prevención de Lesión Iatrogénica de Vía Biliar',
            durationMinutes: 25,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 7. GINECOLOGÍA Y OBSTETRICIA
  {
    id: 'med-c7',
    title: 'Ginecología y Obstetricia de Alto Riesgo',
    slug: 'ginecologia-obstetricia-alto-riesgo',
    shortDescription: 'Hemorragia posparto (Código Rojo), preeclampsia severa, ecografía fetal morfológica y cirugía ginecológica mínimamente invasiva.',
    description: 'Protocolos de atención materna crítica. Aprende el balón de taponamiento intrauterino (Bakri), suturas hemostáticas compresivas de B-Lynch, diagnóstico prenatal del primer y segundo trimestre, y laparoscopía en endometriosis.',
    category: 'Salud Materno-Infantil',
    level: 'Especialista',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.95,
    ratingCount: 2240,
    studentsCount: 10400,
    thumbnail: 'https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-30',
    cmeCredits: 55,
    hospitalAffiliation: 'Instituto Materno Perinatal',
    accreditationCode: 'CME-OBGYN-2026-G7',
    features: [
      '55 Créditos CME acreditados por Sociedades Ginecológicas',
      'Protocolo Código Rojo para choque hipovolémico obstétrico',
      'Guías de preeclampsia y sulfato de magnesio según ACOG/FIGO'
    ],
    sections: [
      {
        id: 's1-obgyn',
        title: 'Módulo 1: Hemorragia Obstétrica Masiva y Técnicas Quirúrgicas de Rescate',
        order: 1,
        lessons: [
          {
            id: 'l1-c7',
            title: '1. Reanimación Hemostática y Colocación de Balón de Bakri',
            durationMinutes: 27,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 8. TRAUMATOLOGÍA Y CIRUGÍA ORTOPÉDICA
  {
    id: 'med-c8',
    title: 'Traumatología y Cirugía Ortopédica',
    slug: 'traumatologia-cirugia-ortopedica',
    shortDescription: 'Principios AO de osteosíntesis, artroscopía de rodilla y hombro, fracturas de pelvis y reemplazos articulares.',
    description: 'Enfoque biomecánico de las fracturas óseas y lesiones ligamentarias. Aprende reducción anatómica, placas bloqueadas LCP, clavos endomedulares fresados, artroplastia total de cadera y manejo del politraumatizado grave.',
    category: 'Especialidades Quirúrgicas',
    level: 'Alta Especialidad',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 52.99,
    originalPrice: 179.99,
    rating: 4.93,
    ratingCount: 1810,
    studentsCount: 8200,
    thumbnail: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-26',
    cmeCredits: 60,
    hospitalAffiliation: 'Hospital de Traumatología y Ortopedia',
    accreditationCode: 'CME-TRAUMA-2026-H8',
    features: [
      '60 Horas Académicas AO Trauma',
      'Videos de cirugías artroscópicas y osteosíntesis en modelos biológicos',
      'Algoritmo de fracturas expuestas (clasificación de Gustilo-Anderson)'
    ],
    sections: [
      {
        id: 's1-trauma',
        title: 'Módulo 1: Principios AO de Osteosíntesis y Estabilidad Relativa vs Absoluta',
        order: 1,
        lessons: [
          {
            id: 'l1-c8',
            title: '1. Planificación Preoperatoria en Fracturas Articulares Complejas',
            durationMinutes: 24,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 9. MEDICINA INTERNA
  {
    id: 'med-c9',
    title: 'Medicina Interna y Diagnóstico Complejo',
    slug: 'medicina-interna-diagnostico-complejo',
    shortDescription: 'Fiebre de origen desconocido, enfermedades autoinmunes sistémicas, amiloidosis, síndrome metabólico y medicina basada en evidencia.',
    description: 'Cátedra insigne de razonamiento clínico y medicina diagnóstica. Domina el diagnóstico diferencial sistemático, lectura crítica de ensayos clínicos, abordaje del paciente anciano frágil y manejo de comorbilidades múltiples.',
    category: 'Especialidades Clínicas',
    level: 'Todos los niveles',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 149.99,
    rating: 4.96,
    ratingCount: 2600,
    studentsCount: 13800,
    thumbnail: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    status: 'Publicado',
    updatedAt: '2026-09-01',
    cmeCredits: 60,
    hospitalAffiliation: 'Hospital Nacional Arzobispo Loayza',
    accreditationCode: 'CME-INTMED-2026-I9',
    features: [
      '60 Horas de Formación Médica Interna Continua',
      'Resolución de 40 casos clínicos desafiantes tipo CPC (Clinico-Pathological Conferences)',
      'Algoritmos de abordaje del Lupus Eritematoso Sistémico y Vasculitis'
    ],
    sections: [
      {
        id: 's1-intmed',
        title: 'Módulo 1: Abordaje Racional del Síndrome Febril Prolongado',
        order: 1,
        lessons: [
          {
            id: 'l1-c9',
            title: '1. Criterios de Petersdorf y Algoritmo por Fases en Fiebre de Origen Desconocido',
            durationMinutes: 29,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 10. ANESTESIOLOGÍA, REANIMACIÓN Y DOLOR
  {
    id: 'med-c10',
    title: 'Anestesiología, Reanimación y Dolor',
    slug: 'anestesiologia-reanimacion-dolor',
    shortDescription: 'Manejo de vía aérea difícil (videolaringoscopía), ultrasonografía perioperatoria (POCUS), TIVA y bloqueos ecoguiados.',
    description: 'Especialización en seguridad anestésica y medicina perioperatoria. Aprende farmacocinética y farmacodinamia de anestésicos endovenosos (modelo Schnider/Eleveld), monitorización BIS, bloqueos regionales de pared abdominal y tórax (TAP, ESP block).',
    category: 'Especialidades Quirúrgicas',
    level: 'Alta Especialidad',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.95,
    ratingCount: 1530,
    studentsCount: 7400,
    thumbnail: 'https://images.unsplash.com/photo-1579154204601-01588f351e67?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-27',
    cmeCredits: 55,
    hospitalAffiliation: 'Centro Quirúrgico y Unidad del Dolor',
    accreditationCode: 'CME-ANEST-2026-J10',
    features: [
      '55 Créditos CME avalados por Sociedades de Anestesia',
      'Video atlas ecográfico de plexos nerviosos y bloqueos fasciales',
      'Simuladores de perfusión TIVA TCI'
    ],
    sections: [
      {
        id: 's1-anest',
        title: 'Módulo 1: Vía Aérea Difícil y Algoritmos de la ASA',
        order: 1,
        lessons: [
          {
            id: 'l1-c10',
            title: '1. De la Fibrobroncoscopía a la Cricotiroidotomía de Emergencia',
            durationMinutes: 26,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 11. OFTALMOLOGÍA Y MICROCIRUGÍA
  {
    id: 'med-c11',
    title: 'Oftalmología y Microcirugía Ocular',
    slug: 'oftalmologia-microcirugia-ocular',
    shortDescription: 'Facoemulsificación de catarata, glaucoma primario de ángulo abierto, retinopatía diabética, OCT y fondo de ojo.',
    description: 'Diagnóstico biomicroscópico y quirúrgico oftalmológico. Aprende a interpretar tomografías de coherencia óptica (OCT) de mácula y papila, campimetría visual computarizada, inyecciones intravítreas de anti-VEGF y cirugía refractiva.',
    category: 'Especialidades Quirúrgicas',
    level: 'Especialista',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 159.99,
    rating: 4.91,
    ratingCount: 1310,
    studentsCount: 6100,
    thumbnail: 'https://images.unsplash.com/photo-1579684453423-f84349ef60b0?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-19',
    cmeCredits: 45,
    hospitalAffiliation: 'Instituto Nacional de Oftalmología',
    accreditationCode: 'CME-OPHTH-2026-K11',
    features: [
      '45 Créditos CME en Microcirugía Oftalmológica',
      'Video microscópico quirúrgico de Facoemulsificación en HD',
      'Casos de urgencias oftalmológicas (desprendimiento de retina, glaucoma agudo)'
    ],
    sections: [
      {
        id: 's1-ophth',
        title: 'Módulo 1: Glaucoma y Neuropatías Ópticas',
        order: 1,
        lessons: [
          {
            id: 'l1-c11',
            title: '1. Gonioscopía y Análisis de Capas de Fibras Nerviosas en OCT',
            durationMinutes: 21,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 12. OTORRINOLARINGOLOGÍA (ORL)
  {
    id: 'med-c12',
    title: 'Otorrinolaringología y Cirugía de Cabeza y Cuello',
    slug: 'otorrinolaringologia-cabeza-cuello',
    shortDescription: 'Cirugía endoscópica nasosinusal (CENS), vértigo vestibular periférico, hipoacusia neurosensorial y patología tiroidea.',
    description: 'Entrenamiento anatómico y clínico del área ORL. Aprende las maniobras diagnósticas de Dix-Hallpike y de reposicionamiento de Epley, lectura de audiometrías y timpanometrías, laringoscopía flexible y disección cervical.',
    category: 'Especialidades Quirúrgicas',
    level: 'Especialista',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 42.99,
    originalPrice: 149.99,
    rating: 4.89,
    ratingCount: 1180,
    studentsCount: 5400,
    thumbnail: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-15',
    cmeCredits: 45,
    hospitalAffiliation: 'Centro Médico Especializado de Cabeza y Cuello',
    accreditationCode: 'CME-ENT-2026-L12',
    features: [
      '45 Horas Académicas ORL',
      'Videos endoscópicos de senos paranasales y cuerdas vocales',
      'Atlas vestibular para evaluación del paciente vertiginoso'
    ],
    sections: [
      {
        id: 's1-ent',
        title: 'Módulo 1: Vértigo Posicional Paroxístico Benigno (VPPB)',
        order: 1,
        lessons: [
          {
            id: 'l1-c12',
            title: '1. Identificación del Canal Semicircular Afectado y Maniobras de Epley vs Semont',
            durationMinutes: 20,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 13. PSIQUIATRÍA Y SALUD MENTAL
  {
    id: 'med-c13',
    title: 'Psiquiatría y Neuropsicofarmacología',
    slug: 'psiquiatria-neuropsicofarmacologia',
    shortDescription: 'Trastorno bipolar, esquizofrenia refractaria, depresión mayor resistente, psicofarmacología y urgencias psiquiátricas.',
    description: 'Abordaje biopsicosocial basado en el DSM-5-TR y CIE-11. Incluye farmacología comparativa de antipsicóticos de segunda y tercera generación, eutimizantes (Litio, Valproato), psicoterapia basada en evidencia y manejo del riesgo suicida.',
    category: 'Especialidades Clínicas',
    level: 'Todos los niveles',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 39.99,
    originalPrice: 139.99,
    rating: 4.95,
    ratingCount: 1740,
    studentsCount: 8900,
    thumbnail: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-24',
    cmeCredits: 50,
    hospitalAffiliation: 'Instituto Nacional de Salud Mental',
    accreditationCode: 'CME-PSYCH-2026-M13',
    features: [
      '50 Créditos CME de Neuropsiquiatría',
      'Matriz de interacciones farmacológicas de psicofármacos',
      'Entrevistas clínicas simuladas para diagnóstico diferencial'
    ],
    sections: [
      {
        id: 's1-psych',
        title: 'Módulo 1: Psicofarmacología de Precisión y Depresión Resistente',
        order: 1,
        lessons: [
          {
            id: 'l1-c13',
            title: '1. Mecanismo de Acción y Perfil Receptor de los Antipsicóticos Atípicos',
            durationMinutes: 27,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 14. RADIOLOGÍA E IMAGEN DIAGNÓSTICA
  {
    id: 'med-c14',
    title: 'Radiología e Imagen Diagnóstica Avanzada',
    slug: 'radiologia-imagen-diagnostica',
    shortDescription: 'Tomografía computarizada multidetector (TCMD), Resonancia Magnética (RM), ecografía Doppler y radiología intervencionista.',
    description: 'Interpretación sistemática de estudios de neuroimagen, tórax de alta resolución (TACAR), abdomen agudo, resonancia musculoesquelética y ecografía vascular Doppler. Protocolo estandarizado de reporte radiológico estructurado.',
    category: 'Diagnóstico & Imagen',
    level: 'Alta Especialidad',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.97,
    ratingCount: 2320,
    studentsCount: 11900,
    thumbnail: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-31',
    cmeCredits: 60,
    hospitalAffiliation: 'Centro de Diagnóstico por Imágenes y Resonancia',
    accreditationCode: 'CME-RAD-2026-N14',
    features: [
      '60 Horas Acreditadas en Diagnóstico por Imagen',
      'Visor DICOM web interactivo con 100 casos clínicos reales',
      'Clasificaciones LI-RADS, PI-RADS, TI-RADS y BI-RADS explicadas paso a paso'
    ],
    sections: [
      {
        id: 's1-rad',
        title: 'Módulo 1: Tomografía de Tórax de Alta Resolución (TACAR) en Neumopatías',
        order: 1,
        lessons: [
          {
            id: 'l1-c14',
            title: '1. Patrón en Vidrio Deslustrado, Empedrado y Neumonía Intersticial Usual (NIU)',
            durationMinutes: 31,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 15. ENDOCRINOLOGÍA, METABOLISMO Y DIABETES
  {
    id: 'med-c15',
    title: 'Endocrinología, Diabetes y Metabolismo',
    slug: 'endocrinologia-diabetes-metabolismo',
    shortDescription: 'Manejo intensivo de Diabetes Mellitus tipo 1 y 2, tecnología aplicada (bombas e infusores continuos), tiroides y suprarrenales.',
    description: 'Directrices de la American Diabetes Association (ADA 2026) y Endocrine Society. Aprende monitoreo continuo de glucosa (MCG), dosificación de análogos GLP-1 y coagonistas duales GIP/GLP-1, diagnóstico de nódulo tiroideo y síndrome de Cushing.',
    category: 'Especialidades Clínicas',
    level: 'Especialista',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 149.99,
    rating: 4.93,
    ratingCount: 1690,
    studentsCount: 8100,
    thumbnail: 'https://images.unsplash.com/photo-1584362917165-526a968579e8?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-21',
    cmeCredits: 50,
    hospitalAffiliation: 'Instituto de Diabetes y Enfermedades Metabólicas',
    accreditationCode: 'CME-ENDO-2026-O15',
    features: [
      '50 Horas Académicas CME',
      'Lectura e interpretación de perfiles ambulatorios de glucosa (AGP)',
      'Protocolos de cetoacidosis diabética y estado hiperosmolar hiperglucémico'
    ],
    sections: [
      {
        id: 's1-endo',
        title: 'Módulo 1: Nuevas Terapias Incretínicas en Diabetes y Obesidad',
        order: 1,
        lessons: [
          {
            id: 'l1-c15',
            title: '1. Agonistas del Receptor GLP-1 y Protección Cardiorrenal',
            durationMinutes: 23,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 16. GASTROENTEROLOGÍA Y ENDOSCOPÍA
  {
    id: 'med-c16',
    title: 'Gastroenterología y Endoscopía Digestiva',
    slug: 'gastroenterologia-endoscopia-digestiva',
    shortDescription: 'Hemorragia digestiva alta y baja, hepatopatía crónica, cirrosis descompensada, EII (Crohn y Colitis Ulcerosa) y CPRE.',
    description: 'Enfermedades del tracto digestivo y glándulas anexas. Domina la hemostasia endoscópica con bandas y clips, estadificación de Child-Pugh y MELD en cirrosis hepática, esteatohepatitis asociada a disfunción metabólica (MASH) y manejo de pancreatitis aguda.',
    category: 'Especialidades Clínicas',
    level: 'Alta Especialidad',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.96,
    ratingCount: 1890,
    studentsCount: 9400,
    thumbnail: 'https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-29',
    cmeCredits: 55,
    hospitalAffiliation: 'Unidad de Endoscopía Digestiva Avanzada',
    accreditationCode: 'CME-GASTRO-2026-P16',
    features: [
      '55 Créditos CME acreditados',
      'Videos de polipectomías complejas y disección submucosa endoscópica',
      'Guía de profilaxis de hemorragia por várices esofágicas'
    ],
    sections: [
      {
        id: 's1-gastro',
        title: 'Módulo 1: Hemorragia Digestiva Alta Variceal y No Variceal',
        order: 1,
        lessons: [
          {
            id: 'l1-c16',
            title: '1. Escala de Rockall y Glasgow-Blatchford en la Toma de Decisiones',
            durationMinutes: 26,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 17. NEUMOLOGÍA Y FISIOLOGÍA RESPIRATORIA
  {
    id: 'med-c17',
    title: 'Neumología y Fisiología Respiratoria',
    slug: 'neumologia-fisiologia-respiratoria',
    shortDescription: 'EPOC, asma grave no controlada, tromboembolismo pulmonar (TEP), fibrosis pulmonar idiopática y espirometría.',
    description: 'Evaluación integral de la función pulmonar y patología torácica. Incluye curvas de flujo-volumen en espirometría, prueba de difusión de monóxido de carbono (DLCO), cálculo de la probabilidad clínica de Wells para TEP y ventilación no invasiva (BiPAP/CPAP).',
    category: 'Especialidades Clínicas',
    level: 'Especialista',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 154.99,
    rating: 4.92,
    ratingCount: 1470,
    studentsCount: 7200,
    thumbnail: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-18',
    cmeCredits: 50,
    hospitalAffiliation: 'Instituto Nacional del Tórax y Fisiología Respiratoria',
    accreditationCode: 'CME-PULM-2026-Q17',
    features: [
      '50 Créditos CME avalados por ERS/ALAT',
      'Taller interactivo de curvas espirométricas y gasometría arterial',
      'Guías GOLD 2026 de EPOC y GINA 2026 de Asma'
    ],
    sections: [
      {
        id: 's1-pulm',
        title: 'Módulo 1: Tromboembolia Pulmonar Masiva y Submasiva',
        order: 1,
        lessons: [
          {
            id: 'l1-c17',
            title: '1. Estratificación del Riesgo con Dímero D, Troponinas y Ecocardiograma en TEP',
            durationMinutes: 24,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 18. NEFROLOGÍA CLÍNICA Y DIÁLISIS
  {
    id: 'med-c18',
    title: 'Nefrología Clínica y Terapia Dialítica',
    slug: 'nefrologia-clinica-terapia-dialitica',
    shortDescription: 'Lesión renal aguda (KDIGO), enfermedad renal crónica, glomerulopatías, trastornos hidroelectrolíticos y hemodiálisis.',
    description: 'Fisiopatología renal avanzada. Aprende a calcular el aclaramiento de creatinina, interpretar sedimento urinario patológico, manejar hiperpotasemia grave refractaria, dosificar en hemodiálisis continua y planificar el trasplante renal.',
    category: 'Especialidades Clínicas',
    level: 'Alta Especialidad',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 49.99,
    originalPrice: 169.99,
    rating: 4.94,
    ratingCount: 1390,
    studentsCount: 6800,
    thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-23',
    cmeCredits: 55,
    hospitalAffiliation: 'Centro Nacional de Salud Renal',
    accreditationCode: 'CME-NEPHRO-2026-R18',
    features: [
      '55 Créditos CME KDIGO',
      'Calculadoras osmolares y fórmulas de corrección electrolítica',
      'Atlas microscópico de cilindros urinarios y biopsia renal'
    ],
    sections: [
      {
        id: 's1-nephro',
        title: 'Módulo 1: Criterios KDIGO y Terapia de Reemplazo Renal Agudo',
        order: 1,
        lessons: [
          {
            id: 'l1-c18',
            title: '1. Indicaciones Absolutas de Diálisis de Urgencia (AEIOU)',
            durationMinutes: 22,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 19. UROLOGÍA Y CIRUGÍA ROBÓTICA
  {
    id: 'med-c19',
    title: 'Urología y Cirugía Endourológica',
    slug: 'urologia-cirugia-endourologica',
    shortDescription: 'Litiasis urinaria con láser Holmium/Tulio, hiperplasia benigna de próstata (HoLEP), cáncer urológico y cirugía Da Vinci.',
    description: 'Enfoque médico y quirúrgico de las vías urinarias masculinas y femeninas. Incluye técnicas endoscópicas de ureterorrenoscopía flexible digital, prostatectomía radical robótica, manejo de sepsis urológica y disfunción eréctil.',
    category: 'Especialidades Quirúrgicas',
    level: 'Alta Especialidad',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 54.99,
    originalPrice: 189.99,
    rating: 4.96,
    ratingCount: 1610,
    studentsCount: 7100,
    thumbnail: 'https://images.unsplash.com/photo-1581595220892-b0739db3ba8c?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-25',
    cmeCredits: 60,
    hospitalAffiliation: 'Instituto Urológico y Centro Robótico',
    accreditationCode: 'CME-URO-2026-S19',
    features: [
      '60 Horas Acreditadas EAU/AUA',
      'Videos de cirugías robóticas con sistema Da Vinci paso a paso',
      'Técnicas de fragmentación de cálculos con láser de última generación'
    ],
    sections: [
      {
        id: 's1-uro',
        title: 'Módulo 1: Ureterolitotricia Flexible Digital y Enucleación Prostática',
        order: 1,
        lessons: [
          {
            id: 'l1-c19',
            title: '1. Acceso a la Vía Urinaria Superior y Prevención de Lesiones Ureterales',
            durationMinutes: 28,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 20. MEDICINA DE EMERGENCIAS Y CUIDADOS CRÍTICOS (UCI)
  {
    id: 'med-c20',
    title: 'Medicina de Emergencias y Cuidados Críticos (UCI)',
    slug: 'medicina-emergencias-cuidados-criticos',
    shortDescription: 'Shock séptico (Surviving Sepsis Campaign), SDRA, ventilación mecánica protectora, reanimación avanzada ACLS y ecografía POCUS.',
    description: 'Entrenamiento del más alto nivel para el médico en sala de reanimación y unidad de cuidados intensivos. Domina la monitorización hemodinámica invasiva, curvas de presión-volumen en respiradores mecánicos, vasoactivos (Noradrenalina, Vasopresina) y canulación ECMO.',
    category: 'Urgencias & Cuidados Críticos',
    level: 'Alta Especialidad',
    instructorId: 'u1',
    instructorName: 'Dr. Alejandro Morales',
    instructorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    price: 59.99,
    originalPrice: 199.99,
    rating: 4.99,
    ratingCount: 3820,
    studentsCount: 18400,
    thumbnail: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    status: 'Publicado',
    updatedAt: '2026-09-04',
    cmeCredits: 70,
    hospitalAffiliation: 'Unidad de Cuidados Intensivos Médico-Quirúrgica',
    accreditationCode: 'CME-CRITCARE-2026-T20',
    features: [
      '70 Créditos CME de Cuidados Críticos de Alta Especialidad',
      'Simulador completo de parámetros del ventilador mecánico (PEEP, Vt, Driving Pressure)',
      'Algoritmos de choque indiferenciado guiado por ecografía RUSH y BLUE protocol'
    ],
    sections: [
      {
        id: 's1-icu',
        title: 'Módulo 1: Shock Séptico y Resucitación Guiada por Metas Fisiológicas',
        order: 1,
        lessons: [
          {
            id: 'l1-c20',
            title: '1. Bundles de la Hora 1: Lactato, Hemocultivos, Cristaloides y Vasoactivos Precoces',
            durationMinutes: 30,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 21. INFECTOLOGÍA Y ANTIMICROBIANOS
  {
    id: 'med-c21',
    title: 'Infectología Clínica y Microbiología Aplicada',
    slug: 'infectologia-clinica-antimicrobianos',
    shortDescription: 'Infecciones por bacterias multirresistentes (BLEE, KPC), VIH/SIDA (antirretrovirales), tuberculosis multidrogorresistente y PROA.',
    description: 'Gestión racional de antimicrobianos (Programas de Optimización de Antimicrobianos - PROA). Aprende farmacocinética/farmacodinamia (PK/PD) de antibióticos, lectura de antibiogramas por método EUCAST/CLSI, micología invasiva e infecciones en pacientes inmunodeprimidos.',
    category: 'Especialidades Clínicas',
    level: 'Especialista',
    instructorId: 'u3',
    instructorName: 'Dra. Elena Valenzuela',
    instructorAvatar: 'https://images.unsplash.com/photo-1594824813571-638f02614d3f?w=150&auto=format&fit=crop&q=80',
    price: 44.99,
    originalPrice: 154.99,
    rating: 4.95,
    ratingCount: 1620,
    studentsCount: 8300,
    thumbnail: 'https://images.unsplash.com/photo-1584515933487-779824d29309?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-28',
    cmeCredits: 50,
    hospitalAffiliation: 'Instituto de Medicina Tropical e Infectología',
    accreditationCode: 'CME-INFECT-2026-U21',
    features: [
      '50 Horas Académicas en Infectología y PROA',
      'Guía práctica de dosificación de antibióticos en infusión extendida',
      'Algoritmo de neutropenia febril y bacteriemia por catéter'
    ],
    sections: [
      {
        id: 's1-infect',
        title: 'Módulo 1: Bacilos Gram Negativos Multirresistentes y Nuevos Betalactámicos',
        order: 1,
        lessons: [
          {
            id: 'l1-c21',
            title: '1. Manejo de Enterobacterias Productoras de Carbapenemasas con Ceftazidima/Avibactam y Meropenem/Vaborbactam',
            durationMinutes: 25,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  },

  // 22. INMUNOLOGÍA CLÍNICA Y ALERGOLOGÍA
  {
    id: 'med-c22',
    title: 'Inmunología Clínica y Alergología',
    slug: 'inmunologia-clinica-alergologia',
    shortDescription: 'Anafilaxia refractaria, inmunodeficiencias primarias, angioedema hereditario, inmunoterapia con alérgenos y biológicos.',
    description: 'Frontera de la inmunología traslacional y alergología médica. Aprende el diagnóstico molecular por componentes (CRD), pruebas cutáneas de Prick Test, desensibilización farmacológica, uso de anticuerpos monoclonales (Omalizumab, Dupilumab) y manejo inmediato de la anafilaxia con Adrenalina intramuscular.',
    category: 'Especialidades Clínicas',
    level: 'Especialista',
    instructorId: 'u2',
    instructorName: 'Dr. Carlos Santana',
    instructorAvatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    price: 42.99,
    originalPrice: 149.99,
    rating: 4.93,
    ratingCount: 1250,
    studentsCount: 6300,
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&auto=format&fit=crop&q=80',
    promoVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    status: 'Publicado',
    updatedAt: '2026-08-17',
    cmeCredits: 45,
    hospitalAffiliation: 'Centro de Investigación en Inmunología Clínica',
    accreditationCode: 'CME-IMMUNO-2026-V22',
    features: [
      '45 Horas Académicas Acreditadas WAO/EAACI',
      'Protocolo de manejo de anafilaxia con autoinyectores de adrenalina',
      'Interpretación de estudios genéticos en inmunodeficiencias del adulto'
    ],
    sections: [
      {
        id: 's1-immuno',
        title: 'Módulo 1: Reacciones Anafilácticas Graves y Farmacoterapia de Rescate',
        order: 1,
        lessons: [
          {
            id: 'l1-c22',
            title: '1. Adrenalina Precoz en Vasto Lateral del Muslo y Manejo del Shock Bifásico',
            durationMinutes: 22,
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            isCompleted: false
          }
        ]
      }
    ]
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1001',
    transactionCode: 'MED-TRX-2026-9841',
    userId: 'u4',
    userName: 'Dra. María Fernández',
    userEmail: 'maria@edupro.com',
    courseId: 'med-c1',
    courseTitle: 'Cardiología Clínica e Intervencionista',
    amount: 49.99,
    currency: 'USD',
    paymentMethod: 'Tarjeta de Crédito',
    status: 'Completado',
    date: '2026-09-08 17:42',
  },
  {
    id: 'tx-1002',
    transactionCode: 'MED-TRX-2026-7723',
    userId: 'u5',
    userName: 'Dr. Javier Domínguez',
    userEmail: 'javier@edupro.com',
    courseId: 'med-c6',
    courseTitle: 'Cirugía General y Laparoscópica Avanzada',
    amount: 59.99,
    currency: 'USD',
    paymentMethod: 'PayPal',
    status: 'Completado',
    date: '2026-09-08 14:19',
  },
  {
    id: 'tx-1003',
    transactionCode: 'MED-TRX-2026-5512',
    userId: 'u4',
    userName: 'Dra. María Fernández',
    userEmail: 'maria@edupro.com',
    courseId: 'med-c20',
    courseTitle: 'Medicina de Emergencias y Cuidados Críticos (UCI)',
    amount: 59.99,
    currency: 'USD',
    paymentMethod: 'Mercado Pago',
    status: 'Completado',
    date: '2026-09-07 19:30',
  },
  {
    id: 'tx-1004',
    transactionCode: 'MED-TRX-2026-3390',
    userId: 'u7',
    userName: 'Dr. Rodrigo Benítez',
    userEmail: 'rodrigo@inactivo.com',
    courseId: 'med-c1',
    courseTitle: 'Cardiología Clínica e Intervencionista',
    amount: 49.99,
    currency: 'USD',
    paymentMethod: 'Tarjeta de Crédito',
    status: 'Reembolsado',
    date: '2026-09-06 10:12',
  },
  {
    id: 'tx-1005',
    transactionCode: 'MED-TRX-2026-1120',
    userId: 'u1',
    userName: 'Dr. Alejandro Morales',
    userEmail: 'admin@edupro.com',
    courseId: 'med-c2',
    courseTitle: 'Neurología y Neurociencias Clínicas',
    amount: 49.99,
    currency: 'USD',
    paymentMethod: 'Tarjeta de Crédito',
    status: 'Completado',
    date: '2026-09-05 16:55',
  },
  {
    id: 'tx-1006',
    transactionCode: 'MED-TRX-2026-8821',
    userId: 'u5',
    userName: 'Dr. Javier Domínguez',
    userEmail: 'javier@edupro.com',
    courseId: 'med-c8',
    courseTitle: 'Traumatología y Cirugía Ortopédica',
    amount: 52.99,
    currency: 'USD',
    paymentMethod: 'PayPal',
    status: 'Completado',
    date: '2026-09-04 11:20',
  },
  {
    id: 'tx-1007',
    transactionCode: 'MED-TRX-2026-4419',
    userId: 'u4',
    userName: 'Dra. María Fernández',
    userEmail: 'maria@edupro.com',
    courseId: 'med-c3',
    courseTitle: 'Pediatría y Neonatología Integral',
    amount: 44.99,
    currency: 'USD',
    paymentMethod: 'Transferencia',
    status: 'Completado',
    date: '2026-09-03 09:15',
  },
  {
    id: 'tx-1008',
    transactionCode: 'MED-TRX-2026-3199',
    userId: 'u4',
    userName: 'Dra. María Fernández',
    userEmail: 'maria@edupro.com',
    courseId: 'med-c7',
    courseTitle: 'Ginecología y Obstetricia de Alto Riesgo',
    amount: 49.99,
    currency: 'USD',
    paymentMethod: 'Tarjeta de Crédito',
    status: 'Completado',
    date: '2026-09-02 12:10',
  }
];

export const INITIAL_CONFIG: SystemConfig = {
  platformName: 'MedEdu Pro - Campus Internacional de Especialidades Médicas',
  platformEmail: 'acreditacion@mededupro.org',
  currency: 'USD',
  currencySymbol: '$',
  taxPercent: 0, // Educación médica exenta o configurada
  allowRegistration: true,
  requireEmailVerification: true,
  stripeEnabled: true,
  paypalEnabled: true,
  mercadoPagoEnabled: true,
  allowCertificates: true,
  primaryColor: '#F97316',
};
